# **App Name**: Siksha Shakti

## Core Features:

- User Authentication: Secure student and teacher login/registration using JWT.
- Personalized Learning Roadmap: Generative AI creates tailored learning paths based on student diagnostic assessments using Gemini as a tool.
- Adaptive Micro-Lessons with Quizzes: Micro-lessons featuring adaptive quizzes which adjust difficulty based on student performance, and student progress tracked.
- Recall Booster: Students use a UI button to request an AI-generated topic summary as a recall tool (Gemini).
- AI-Formed Collaboration Pods: The generative AI suggests and forms synergistic peer groups with options of peer tutoring, challenges, or reviews (Gemini).
- Educator Insights Dashboard: Dashboard presenting insights such as classroom struggles and concept bottlenecks, which help in teaching and intervention.
- Admin Pod Approval: Teachers will review AI-suggested synergy pods to make a decision about their adoption.

## Style Guidelines:

- Primary color: Deep Indigo (#3F51B5) for a focused learning atmosphere.
- Background color: Very light Indigo (#E8EAF6), almost white, creating a calm, uncluttered feel.
- Accent color: Vibrant Orange (#FF9800) to highlight important actions and elements.
- Body and headline font: 'PT Sans', a humanist sans-serif with a modern and slightly warm feel.
- Use consistent, simple icons for navigation and key features. Ensure icons are intuitive and accessible.
- The layout will have clearly defined sections to improve the user experience. Ensure a clear visual hierarchy with enough whitespace.
- Subtle transitions and animations to enhance user interaction. Avoid distracting or unnecessary animations.