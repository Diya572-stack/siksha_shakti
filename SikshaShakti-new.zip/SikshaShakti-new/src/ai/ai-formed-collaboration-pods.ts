'use server';
/**
 * @fileOverview An AI agent for forming collaboration pods for students.
 *
 * - aiFormedCollaborationPods - A function that handles the pod formation process.
 * - AiFormedCollaborationPodsInput - The input type for the aiFormedCollaborationPods function.
 * - AiFormedCollaborationPodsOutput - The return type for the aiFormedCollaborationPods function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiFormedCollaborationPodsInputSchema = z.object({
  studentLearningNeeds: z
    .string()
    .describe('A description of the student learning needs.'),
  studentSkills: z.array(z.string()).describe('The skills of the student.'),
  studentInterests: z.array(z.string()).describe('The interests of the student.'),
  studentStudyPreferences: z
    .string()
    .describe('The study preferences of the student.'),
  availableStudents: z
    .array(z.object({
      studentId: z.string().describe('The unique identifier of the student.'),
      learningNeeds: z.string().describe('The learning needs of the student.'),
      skills: z.array(z.string()).describe('The skills of the student.'),
      interests: z.array(z.string()).describe('The interests of the student.'),
      studyPreferences: z
        .string()
        .describe('The study preferences of the student.'),
    }))
    .describe('A list of available students to form collaboration pods with.'),
});
export type AiFormedCollaborationPodsInput = z.infer<
  typeof AiFormedCollaborationPodsInputSchema
>;

const AiFormedCollaborationPodsOutputSchema = z.object({
  collaborationPods: z
    .array(z.array(z.string()))
    .describe(
      'A list of collaboration pods, where each pod is a list of student IDs.'
    ),
  reasoning: z.string().describe('The reasoning behind the pod formations.'),
});
export type AiFormedCollaborationPodsOutput = z.infer<
  typeof AiFormedCollaborationPodsOutputSchema
>;

export async function aiFormedCollaborationPods(
  input: AiFormedCollaborationPodsInput
): Promise<AiFormedCollaborationPodsOutput> {
  return aiFormedCollaborationPodsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiFormedCollaborationPodsPrompt',
  input: {schema: AiFormedCollaborationPodsInputSchema},
  output: {schema: AiFormedCollaborationPodsOutputSchema},
  prompt: `You are an AI agent specializing in forming effective collaboration pods for students.

You will receive information about a student's learning needs, skills, interests and study preferences, as well as a list of other available students with similar information.

Your task is to form collaboration pods of 3-5 students, ensuring each pod consists of students that complement each other's learning needs and skills. Consider student interests and study preferences to maximize compatibility.

Student Learning Needs: {{{studentLearningNeeds}}}
Student Skills: {{#if studentSkills}}{{#each studentSkills}}- {{{this}}}\n{{/each}}{{else}}None{{/if}}
Student Interests: {{#if studentInterests}}{{#each studentInterests}}- {{{this}}}\n{{/each}}{{else}}None{{/if}}
Student Study Preferences: {{{studentStudyPreferences}}}

Available Students:{{#each availableStudents}}\n- Student ID: {{{studentId}}}, Learning Needs: {{{learningNeeds}}}, Skills: {{#if skills}}{{#each skills}}- {{{this}}}\n{{/each}}{{else}}None{{/if}}, Interests: {{#if interests}}{{#each interests}}- {{{this}}}\n{{/each}}{{else}}None{{/if}}, Study Preferences: {{{studyPreferences}}}{{/each}}

Output a list of collaboration pods, where each pod is a list of student IDs. Also, include a brief reasoning for the pod formations.

Format your response as a JSON object with "collaborationPods" and "reasoning" fields.
`,
});

const aiFormedCollaborationPodsFlow = ai.defineFlow(
  {
    name: 'aiFormedCollaborationPodsFlow',
    inputSchema: AiFormedCollaborationPodsInputSchema,
    outputSchema: AiFormedCollaborationPodsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
