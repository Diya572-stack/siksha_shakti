import { config } from 'dotenv';
config();

import '@/ai/flows/recall-booster.ts';
import '@/ai/flows/personalized-learning-roadmap.ts';
import '@/ai/flows/video-recall-booster.ts';
