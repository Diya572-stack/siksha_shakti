'use server';
/**
 * @fileOverview Generates a short video summary of a topic using AI.
 *
 * - generateVideoRecallBooster - A function that generates a video summary.
 * - VideoRecallBoosterInput - The input type for the function.
 * - VideoRecallBoosterOutput - The return type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';
import { Readable } from 'stream';
import type { MediaPart } from 'genkit';

const VideoRecallBoosterInputSchema = z.object({
  topic: z.string().describe('The topic to generate a video summary for.'),
});
export type VideoRecallBoosterInput = z.infer<
  typeof VideoRecallBoosterInputSchema
>;

const VideoRecallBoosterOutputSchema = z.object({
  videoUrl: z.string().describe('The data URI of the generated video.'),
});
export type VideoRecallBoosterOutput = z.infer<
  typeof VideoRecallBoosterOutputSchema
>;

export async function generateVideoRecallBooster(
  input: VideoRecallBoosterInput
): Promise<VideoRecallBoosterOutput> {
  return videoRecallBoosterFlow(input);
}

const videoRecallBoosterFlow = ai.defineFlow(
  {
    name: 'videoRecallBoosterFlow',
    inputSchema: VideoRecallBoosterInputSchema,
    outputSchema: VideoRecallBoosterOutputSchema,
  },
  async (input) => {
    let { operation } = await ai.generate({
      model: googleAI.model('veo-2.0-generate-001'),
      prompt: input.topic,
      config: {
        durationSeconds: 5,
        aspectRatio: '16:9',
      },
    });

    if (!operation) {
      throw new Error('Expected the model to return an operation');
    }

    // Wait until the operation completes.
    while (!operation.done) {
      await new Promise((resolve) => setTimeout(resolve, 5000));
      operation = await ai.checkOperation(operation);
    }

    if (operation.error) {
      throw new Error('failed to generate video: ' + operation.error.message);
    }

    const videoPart = operation.output?.message?.content.find((p) => !!p.media);
    if (!videoPart || !videoPart.media) {
      throw new Error('Failed to find the generated video in the operation result');
    }

    const fetch = (await import('node-fetch')).default;
    const videoDownloadResponse = await fetch(
      `${videoPart.media.url}&key=${process.env.GEMINI_API_KEY}`
    );

    if (
      !videoDownloadResponse ||
      videoDownloadResponse.status !== 200 ||
      !videoDownloadResponse.body
    ) {
      throw new Error('Failed to fetch video');
    }
    
    const buffer = await videoDownloadResponse.arrayBuffer();
    const base64 = Buffer.from(buffer).toString('base64');
    
    return {
        videoUrl: `data:video/mp4;base64,${base64}`
    }
  }
);
