'use server';

/**
 * @fileOverview Personalized Learning Roadmap generator.
 *
 * - generatePersonalizedRoadmap - A function that generates a personalized learning roadmap.
 * - PersonalizedRoadmapInput - The input type for the generatePersonalizedRoadmap function.
 * - PersonalizedRoadmapOutput - The return type for the generatePersonalizedRoadmap function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PersonalizedRoadmapInputSchema = z.object({
  diagnosticAssessment: z
    .string()
    .describe('The student diagnostic assessment results.'),
  studentGoals: z.string().describe('The student learning goals.'),
});
export type PersonalizedRoadmapInput = z.infer<typeof PersonalizedRoadmapInputSchema>;

const PersonalizedRoadmapOutputSchema = z.object({
  learningRoadmap: z
    .string()
    .describe('The personalized learning roadmap for the student.'),
});
export type PersonalizedRoadmapOutput = z.infer<typeof PersonalizedRoadmapOutputSchema>;

export async function generatePersonalizedRoadmap(
  input: PersonalizedRoadmapInput
): Promise<PersonalizedRoadmapOutput> {
  return personalizedRoadmapFlow(input);
}

const prompt = ai.definePrompt({
  name: 'personalizedRoadmapPrompt',
  input: {schema: PersonalizedRoadmapInputSchema},
  output: {schema: PersonalizedRoadmapOutputSchema},
  prompt: `You are an expert learning roadmap generator.

  Based on the student's diagnostic assessment and learning goals, generate a personalized learning roadmap.

  Diagnostic Assessment: {{{diagnosticAssessment}}}
  Student Goals: {{{studentGoals}}}

  Roadmap:`,
});

const personalizedRoadmapFlow = ai.defineFlow(
  {
    name: 'personalizedRoadmapFlow',
    inputSchema: PersonalizedRoadmapInputSchema,
    outputSchema: PersonalizedRoadmapOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
