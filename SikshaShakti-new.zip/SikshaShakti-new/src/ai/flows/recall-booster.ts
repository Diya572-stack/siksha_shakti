// 'use server';
/**
 * @fileOverview Generates a summary of a given topic for recall purposes.
 *
 * - generateRecallSummary - A function that generates a summary of a topic.
 * - RecallBoosterInput - The input type for the generateRecallSummary function.
 * - RecallBoosterOutput - The return type for the generateRecallSummary function.
 */

'use server';

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const RecallBoosterInputSchema = z.object({
  topic: z.string().describe('The topic to generate a summary for.'),
});
export type RecallBoosterInput = z.infer<typeof RecallBoosterInputSchema>;

const RecallBoosterOutputSchema = z.object({
  summary: z.string().describe('A summary of the topic.'),
  progress: z.string().describe('The progress of generating the summary.'),
});
export type RecallBoosterOutput = z.infer<typeof RecallBoosterOutputSchema>;

export async function generateRecallSummary(input: RecallBoosterInput): Promise<RecallBoosterOutput> {
  return recallBoosterFlow(input);
}

const prompt = ai.definePrompt({
  name: 'recallBoosterPrompt',
  input: {schema: RecallBoosterInputSchema},
  output: {schema: RecallBoosterOutputSchema},
  prompt: `You are an expert summarizer, skilled at creating concise and informative summaries of complex topics.

  Please provide a summary of the following topic:

  Topic: {{{topic}}}
  `,
});

const recallBoosterFlow = ai.defineFlow(
  {
    name: 'recallBoosterFlow',
    inputSchema: RecallBoosterInputSchema,
    outputSchema: RecallBoosterOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return {
      ...output,
      progress: 'Generated a short summary of the topic.',
    } as RecallBoosterOutput;
  }
);
