import type { User, RoadmapStep, QuizQuestion, Pod, StudentProgress, VideoLesson } from './types';
import { PlaceHolderImages } from './placeholder-images';

const studentAvatar = PlaceHolderImages.find(img => img.id === 'user-avatar-1')?.imageUrl || '';
const teacherAvatar = PlaceHolderImages.find(img => img.id === 'user-avatar-2')?.imageUrl || '';
const student2Avatar = PlaceHolderImages.find(img => img.id === 'user-avatar-3')?.imageUrl || '';
const student3Avatar = PlaceHolderImages.find(img => img.id === 'user-avatar-4')?.imageUrl || '';
const videoThumbnail1 = PlaceHolderImages.find(img => img.id === 'video-thumbnail-1')?.imageUrl || '';
const videoThumbnail2 = PlaceHolderImages.find(img => img.id === 'video-thumbnail-2')?.imageUrl || '';
const videoThumbnail3 = PlaceHolderImages.find(img => img.id === 'video-thumbnail-3')?.imageUrl || '';
const videoThumbnail4 = PlaceHolderImages.find(img => img.id === 'video-thumbnail-4')?.imageUrl || '';


export const mockStudent: User = {
  id: '1',
  name: 'Ananya Sharma',
  email: 'ananya.sharma@example.com',
  role: 'student',
  avatarUrl: studentAvatar,
};

export const mockTeacher: User = {
  id: '2',
  name: 'Mr. Vikram Singh',
  email: 'vikram.singh@example.com',
  role: 'teacher',
  avatarUrl: teacherAvatar,
};

export const mockRoadmap: RoadmapStep[] = [
  { id: '1', title: 'Introduction to Algebra', description: 'Basics of variables, expressions, and equations.', status: 'completed', resourceCount: 5 },
  { id: '2', title: 'Linear Equations', description: 'Solving single and multi-step linear equations.', status: 'completed', resourceCount: 8 },
  { id: '3', title: 'Functions and Relations', description: 'Understanding functions, domain, and range.', status: 'in-progress', resourceCount: 6 },
  { id: '4', title: 'Quadratic Equations', description: 'Factoring, completing the square, and quadratic formula.', status: 'locked', resourceCount: 10 },
  { id: '5', title: 'Polynomials', description: 'Operations with polynomials and their properties.', status: 'locked', resourceCount: 7 },
];

export const mockQuiz: QuizQuestion[] = [
  {
    id: 'q1',
    question: 'What is the value of x in the equation 2x + 5 = 15?',
    options: ['3', '5', '7', '10'],
    correctAnswer: '5',
  },
  {
    id: 'q2',
    question: 'Which of these is a linear equation?',
    options: ['y = x^2 + 1', 'y = 2x + 3', 'y = sqrt(x)', 'y = 1/x'],
    correctAnswer: 'y = 2x + 3',
  },
];

export const mockStudents: StudentProgress[] = [
    { id: 's1', name: 'Rohan Joshi', progress: 85, avatarUrl: student2Avatar, isStruggling: false },
    { id: 's2', name: 'Priya Mehta', progress: 42, avatarUrl: student3Avatar, isStruggling: true },
    { id: 's3', name: 'Kabir Khan', progress: 68, avatarUrl: studentAvatar, isStruggling: false },
    { id: 's4', name: 'Ishita Reddy', progress: 91, avatarUrl: student2Avatar, isStruggling: false },
    { id: 's5', name: 'Arjun Das', progress: 35, avatarUrl: student3Avatar, isStruggling: true },
];

export const mockPods: Pod[] = [
  {
    id: 'p1',
    name: 'Algebra Avengers',
    type: 'Challenge Pod',
    members: [mockStudents[0], mockStudents[3]],
    subject: 'Advanced Algebra',
    status: 'suggested',
  },
  {
    id: 'p2',
    name: 'Calculus Crew',
    type: 'Peer Tutoring',
    members: [mockStudents[1], mockStudents[4], mockStudents[2]],
    subject: 'Calculus Basics',
    status: 'suggested',
  },
  {
    id: 'p3',
    name: 'Geometry Gurus',
    type: 'Review Pod',
    members: [mockStudents[0], mockStudents[2], mockStudents[3]],
    subject: 'Euclidean Geometry',
    status: 'active',
  },
];

export const mockConceptMastery = [
  { name: 'Linear Equations', mastery: 92, students: 28 },
  { name: 'Functions', mastery: 78, students: 25 },
  { name: 'Quadratics', mastery: 65, students: 21 },
  { name: 'Polynomials', mastery: 45, students: 15 },
  { name: 'Trigonometry', mastery: 38, students: 12 },
];

export const mockVideoLessons: VideoLesson[] = [
  {
    id: 'v1',
    title: 'Solving Multi-Step Equations',
    description: 'A deep dive into the strategies for solving complex linear equations.',
    thumbnailUrl: videoThumbnail1,
    videoUrl: 'https://www.youtube.com/embed/xtIr4l7oY3k',
  },
  {
    id: 'v2',
    title: 'Understanding Function Notation',
    description: 'Learn how to read and use function notation like f(x).',
    thumbnailUrl: videoThumbnail2,
    videoUrl: 'https://www.youtube.com/embed/PDIudNFEoGw',
  },
  {
    id: 'v3',
    title: 'Python Tutorial for Beginners',
    description: 'A full course for beginners to learn Python.',
    thumbnailUrl: videoThumbnail3,
    videoUrl: 'https://www.youtube.com/embed/UrsmFxEIp5k',
  },
];
