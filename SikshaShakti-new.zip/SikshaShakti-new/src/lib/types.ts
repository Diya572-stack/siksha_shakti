export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'teacher';
  avatarUrl: string;
}

export interface RoadmapStep {
  id: string;
  title: string;
  description: string;
  status: 'completed' | 'in-progress' | 'locked';
  resourceCount: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
}

export type PodType = 'Peer Tutoring' | 'Challenge Pod' | 'Review Pod';

export interface Pod {
  id: string;
  name: string;
  type: PodType;
  members: User[];
  subject: string;
  status: 'suggested' | 'active' | 'archived';
}

export interface StudentProgress {
  id: string;
  name: string;
  progress: number;
  avatarUrl: string;
  isStruggling: boolean;
}

export interface VideoLesson {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
}
