import { ClassroomInsights } from "@/components/dashboard/teacher/ClassroomInsights";
import { PodSuggestions } from "@/components/dashboard/teacher/PodSuggestions";
import { mockTeacher } from "@/lib/mock-data";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function TeacherDashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">
        Welcome, {mockTeacher.name}!
      </h1>
      <Tabs defaultValue="insights">
        <TabsList className="grid w-full grid-cols-2 md:w-[400px]">
          <TabsTrigger value="insights">Classroom Insights</TabsTrigger>
          <TabsTrigger value="pods">Pod Suggestions</TabsTrigger>
        </TabsList>
        <TabsContent value="insights" className="mt-6">
          <ClassroomInsights />
        </TabsContent>
        <TabsContent value="pods" className="mt-6">
          <PodSuggestions />
        </TabsContent>
      </Tabs>
    </div>
  );
}
