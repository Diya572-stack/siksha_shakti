import { QuizClient } from "@/components/dashboard/student/QuizClient";

export default function QuizPage() {
  return (
    <div className="space-y-6 flex flex-col items-center">
      <div className="text-center">
        <h1 className="text-3xl font-bold tracking-tight">Module Quiz: Linear Equations</h1>
        <p className="text-muted-foreground">Test your knowledge and adapt your learning.</p>
      </div>
      <QuizClient />
    </div>
  );
}
