import { ProgressOverview } from "@/components/dashboard/student/ProgressOverview";
import { RoadmapPreview } from "@/components/dashboard/student/RoadmapPreview";
import { RecallBooster } from "@/components/dashboard/student/RecallBooster";
import { VideoLessons } from "@/components/dashboard/student/VideoLessons";
import { mockStudent } from "@/lib/mock-data";

export default function StudentDashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Welcome back, {mockStudent.name.split(' ')[0]}!</h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <ProgressOverview />
        <RoadmapPreview />
        <RecallBooster />
        <VideoLessons />
      </div>
    </div>
  );
}
