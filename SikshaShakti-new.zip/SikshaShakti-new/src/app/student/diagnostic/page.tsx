'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { generatePersonalizedRoadmap } from '@/ai/flows/personalized-learning-roadmap';

export default function DiagnosticPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [goals, setGoals] = useState('');
  const [assessment, setAssessment] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [roadmap, setRoadmap] = useState<string | null>(null);

  const handleSubmit = async () => {
    if (!goals.trim() || !assessment.trim()) {
      toast({
        title: 'Fields Required',
        description: 'Please fill out both your goals and assessment.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);
    setRoadmap(null);
    try {
      const result = await generatePersonalizedRoadmap({
        studentGoals: goals,
        diagnosticAssessment: assessment,
      });
      setRoadmap(result.learningRoadmap);
      toast({
        title: 'Roadmap Generated!',
        description: 'Your personalized learning path is ready.',
      });
       // In a real app, you'd save this roadmap and then redirect.
      // For now, we display it on the same page.
      // setTimeout(() => router.push('/student/roadmap'), 2000);
    } catch (error) {
      console.error(error);
      toast({
        title: 'Generation Failed',
        description: 'Could not generate roadmap. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="text-2xl">Create Your Learning Path</CardTitle>
          <CardDescription>
            Tell us about your goals and what you already know to generate a personalized roadmap.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="goals">What are your learning goals?</Label>
            <Textarea
              id="goals"
              placeholder="e.g., 'I want to prepare for my final exams in Algebra.' or 'I want to understand calculus for my physics class.'"
              value={goals}
              onChange={(e) => setGoals(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="assessment">Briefly describe your current understanding or challenges.</Label>
            <Textarea
              id="assessment"
              placeholder="e.g., 'I am comfortable with basic equations but struggle with word problems.' or 'I find functions confusing.'"
              value={assessment}
              onChange={(e) => setAssessment(e.target.value)}
            />
          </div>
          <Button onClick={handleSubmit} disabled={isLoading} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Roadmap...
              </>
            ) : (
              'Generate My Roadmap'
            )}
          </Button>

          {roadmap && (
            <div className="mt-6 rounded-lg border bg-secondary/50 p-4">
              <h3 className="mb-2 text-lg font-semibold">Your AI-Generated Roadmap:</h3>
              <p className="whitespace-pre-wrap text-sm">{roadmap}</p>
                 <Button onClick={() => router.push('/student/dashboard')} className="mt-4 w-full">
                    Go to Dashboard
                 </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
