'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { mockQuiz } from '@/lib/mock-data';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

export function QuizClient() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);

  const currentQuestion = mockQuiz[currentQuestionIndex];
  const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

  const handleAnswer = () => {
    if (!selectedAnswer) return;
    setIsAnswered(true);
    if (isCorrect) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    setIsAnswered(false);
    setSelectedAnswer(null);
    setCurrentQuestionIndex(currentQuestionIndex + 1);
  };
  
  const handleRestart = () => {
    setCurrentQuestionIndex(0);
    setScore(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
  }

  const progress = ((currentQuestionIndex) / mockQuiz.length) * 100;

  if (currentQuestionIndex >= mockQuiz.length) {
    return (
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Quiz Complete!</CardTitle>
          <CardDescription>You've finished the quiz.</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-4xl font-bold">Your Score: {score} / {mockQuiz.length}</p>
        </CardContent>
        <CardFooter>
          <Button onClick={handleRestart} className="w-full">Restart Quiz</Button>
        </CardFooter>
      </Card>
    )
  }

  return (
    <div className="w-full max-w-2xl space-y-4">
       <Progress value={progress} />
      <Card>
        <CardHeader>
          <CardTitle>Question {currentQuestionIndex + 1}</CardTitle>
          <CardDescription className="text-lg pt-2">{currentQuestion.question}</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={selectedAnswer ?? undefined}
            onValueChange={setSelectedAnswer}
            disabled={isAnswered}
          >
            {currentQuestion.options.map((option) => (
              <Label
                key={option}
                htmlFor={option}
                className={cn(
                  'flex items-center space-x-3 rounded-md border p-4 transition-colors',
                  isAnswered && option === currentQuestion.correctAnswer && 'bg-green-100 border-green-400 dark:bg-green-900/50',
                  isAnswered && option === selectedAnswer && !isCorrect && 'bg-red-100 border-red-400 dark:bg-red-900/50',
                  !isAnswered && 'hover:bg-accent/50 cursor-pointer'
                )}
              >
                <RadioGroupItem value={option} id={option} />
                <span>{option}</span>
              </Label>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex-col items-stretch space-y-4">
          {isAnswered && (
            <div className={cn(
                "flex items-center gap-2 rounded-md p-3 text-sm",
                isCorrect ? "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300" : "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300"
            )}>
              {isCorrect ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
              <span>{isCorrect ? 'Correct!' : `Incorrect. The correct answer is ${currentQuestion.correctAnswer}.`}</span>
            </div>
          )}
          {isAnswered ? (
            <Button onClick={handleNext} className="w-full">
              {currentQuestionIndex === mockQuiz.length - 1 ? 'Finish Quiz' : 'Next Question'}
            </Button>
          ) : (
            <Button onClick={handleAnswer} disabled={!selectedAnswer} className="w-full">
              Submit Answer
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
