import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export function ProgressOverview() {
  const overallProgress = 65; // Mock data
  const completedModules = 2;
  const totalModules = 5;

  return (
    <Card>
      <CardHeader>
        <CardTitle>My Progress</CardTitle>
        <CardDescription>
          You have completed {completedModules} out of {totalModules} modules.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between text-sm font-medium">
            <span>Overall Progress</span>
            <span>{overallProgress}%</span>
          </div>
          <Progress value={overallProgress} aria-label={`${overallProgress}% complete`} />
        </div>
      </CardContent>
    </Card>
  );
}
