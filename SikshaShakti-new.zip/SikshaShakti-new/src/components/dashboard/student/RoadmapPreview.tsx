import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Circle, Milestone } from "lucide-react";
import { mockRoadmap } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export function RoadmapPreview() {
  const nextStep = mockRoadmap.find(step => step.status === 'in-progress');

  return (
    <Card className="flex flex-col">
      <CardHeader>
        <CardTitle>Learning Roadmap</CardTitle>
        {nextStep ? (
          <CardDescription>Your next step is: <strong>{nextStep.title}</strong></CardDescription>
        ) : (
          <CardDescription>You've completed your roadmap!</CardDescription>
        )}
      </CardHeader>
      <CardContent className="flex-1">
        <ul className="space-y-3">
          {mockRoadmap.slice(0, 3).map((step) => (
            <li key={step.id} className="flex items-center gap-3">
              {step.status === 'completed' ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : (
                <Circle className={cn(
                  "h-5 w-5",
                  step.status === 'in-progress' ? 'text-primary' : 'text-muted-foreground'
                )} />
              )}
              <span className={cn(
                "text-sm font-medium",
                step.status === 'locked' && 'text-muted-foreground'
              )}>
                {step.title}
              </span>
            </li>
          ))}
        </ul>
      </CardContent>
      <div className="p-6 pt-0">
        <Button asChild className="w-full" variant="outline">
          <Link href="/student/roadmap">
            <Milestone className="mr-2 h-4 w-4" />
            View Full Roadmap
          </Link>
        </Button>
      </div>
    </Card>
  );
}
