'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BrainCircuit, Loader2, Video } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function RecallBooster() {
  const [videoUrl, setVideoUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const dummyVideoUrl = "https://www.youtube.com/embed/fxJdmBM0SYs?autoplay=1&controls=0&loop=1&playlist=fxJdmBM0SYs";

  const handleGenerateVideo = async () => {
    setIsLoading(true);
    setVideoUrl('');

    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      setVideoUrl(dummyVideoUrl);
      toast({
        title: 'Recall Video Generated!',
        description: 'Your AI-powered video summary is ready to watch.',
      });
    } catch (error) {
      console.error('Error generating video:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate video. Please try again later.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BrainCircuit className="h-6 w-6 text-primary" />
          AI Recall Booster
        </CardTitle>
        <CardDescription>Generate a quick AI-powered video summary of your last lesson to reinforce learning.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-lg border bg-secondary/50 p-4 min-h-[200px] flex items-center justify-center aspect-video overflow-hidden">
            {isLoading ? (
                <div className="flex flex-col items-center gap-2 text-secondary-foreground">
                    <Loader2 className="h-8 w-8 animate-spin" />
                    <p>Generating your video...</p>
                    <p className="text-xs">(This may take a moment)</p>
                </div>
            ) : videoUrl ? (
                <iframe 
                    src={videoUrl} 
                    title="Recall Booster Video"
                    className="w-full h-full"
                    allow="autoplay; encrypted-media"
                    allowFullScreen
                />
            ) : (
                <div className="text-center text-secondary-foreground">
                    <Video className="mx-auto h-12 w-12" />
                    <h3 className="mt-2 font-semibold">Your recall video will appear here.</h3>
                    <p className="text-sm">Click the button below to generate a summary video.</p>
                </div>
            )}
        </div>
        <Button onClick={handleGenerateVideo} disabled={isLoading} className="w-full md:w-auto">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            'Generate Recall Video'
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
