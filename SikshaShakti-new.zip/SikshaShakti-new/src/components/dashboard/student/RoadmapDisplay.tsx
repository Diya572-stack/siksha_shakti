import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { mockRoadmap } from "@/lib/mock-data";
import { Check, Lock, BookOpen } from "lucide-react";
import { cn } from "@/lib/utils";

export function RoadmapDisplay() {
  const getIcon = (status: 'completed' | 'in-progress' | 'locked') => {
    switch (status) {
      case 'completed':
        return <Check className="h-5 w-5 text-white" />;
      case 'in-progress':
        return <BookOpen className="h-5 w-5 text-white" />;
      case 'locked':
        return <Lock className="h-5 w-5 text-white" />;
    }
  };

  const getIconBgColor = (status: 'completed' | 'in-progress' | 'locked') => {
    switch (status) {
      case 'completed':
        return "bg-green-500";
      case 'in-progress':
        return "bg-primary";
      case 'locked':
        return "bg-muted-foreground/50";
    }
  };

  return (
    <div className="relative pl-8">
      {/* Vertical line */}
      <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border -translate-x-1/2"></div>
      
      <div className="space-y-8">
        {mockRoadmap.map((step) => (
          <div key={step.id} className="relative flex items-start">
            <div className={cn(
              "absolute left-0 top-1.5 -translate-x-1/2 flex h-8 w-8 items-center justify-center rounded-full z-10",
              getIconBgColor(step.status)
            )}>
              {getIcon(step.status)}
            </div>
            <Card className={cn(
              "ml-8 w-full transition-all",
              step.status === 'locked' && 'bg-muted/50 border-dashed',
              step.status === 'in-progress' && 'border-primary border-2 shadow-lg'
            )}>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>{step.title}</CardTitle>
                  <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-md">
                    {step.resourceCount} Resources
                  </span>
                </div>
                <CardDescription className={cn(step.status === 'locked' && 'text-muted-foreground/80')}>
                  {step.description}
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}
