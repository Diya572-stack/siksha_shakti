'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlayCircle, Video } from 'lucide-react';
import { mockVideoLessons } from '@/lib/mock-data';
import Image from 'next/image';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export function VideoLessons() {
  const [selectedVideo, setSelectedVideo] = useState<{title: string, url: string} | null>(null);

  return (
    <Card className="col-span-1 lg:col-span-3">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Video className="h-6 w-6 text-primary" />
          Recommended Video Lessons
        </CardTitle>
        <CardDescription>
          Watch these short videos to supplement your learning on current topics.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Dialog onOpenChange={(isOpen) => !isOpen && setSelectedVideo(null)}>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {mockVideoLessons.map((lesson) => (
              <DialogTrigger key={lesson.id} asChild onClick={() => setSelectedVideo({title: lesson.title, url: lesson.videoUrl})}>
                <div className="group relative cursor-pointer overflow-hidden rounded-lg">
                  <Image
                    src={lesson.thumbnailUrl}
                    alt={lesson.title}
                    width={600}
                    height={400}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    data-ai-hint="lesson thumbnail"
                  />
                  <div className="absolute inset-0 bg-black/50 flex flex-col justify-between p-4">
                    <div>
                      <h3 className="font-bold text-lg text-white">{lesson.title}</h3>
                      <p className="text-sm text-white/80 line-clamp-2">{lesson.description}</p>
                    </div>
                    <div className="flex items-center justify-center">
                        <PlayCircle className="h-16 w-16 text-white/80 transition-transform duration-300 group-hover:scale-110 group-hover:text-white" />
                    </div>
                    <div />
                  </div>
                </div>
              </DialogTrigger>
            ))}
          </div>
          {selectedVideo && (
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                 <DialogTitle>{selectedVideo.title}</DialogTitle>
              </DialogHeader>
              <div className="aspect-video">
                <iframe
                  src={selectedVideo.url}
                  title={selectedVideo.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  className="h-full w-full rounded-lg"
                ></iframe>
              </div>
            </DialogContent>
          )}
        </Dialog>
      </CardContent>
    </Card>
  );
}
