'use client';

import { useState } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { mockPods } from '@/lib/mock-data';
import { Check, X, Users, Lightbulb } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function PodSuggestions() {
  const [pods, setPods] = useState(mockPods.filter(p => p.status === 'suggested'));
  const { toast } = useToast();

  const handleDecision = (podId: string, decision: 'approved' | 'rejected') => {
    setPods(pods.filter(p => p.id !== podId));
    toast({
      title: `Pod ${decision}`,
      description: `The pod has been ${decision}.`,
    });
  };
  
  const getInitials = (name: string) => {
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`;
    }
    return name.substring(0, 2);
  };

  if (pods.length === 0) {
    return (
        <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-12 text-center">
            <Users className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-semibold">No Pod Suggestions</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              There are no new AI-generated pod suggestions at this time.
            </p>
        </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
      {pods.map(pod => (
        <Card key={pod.id} className="flex flex-col">
          <CardHeader>
             <div className="flex items-center justify-between">
                <CardTitle>{pod.name}</CardTitle>
                <Badge variant="outline">{pod.type}</Badge>
            </div>
            <CardDescription>Subject: {pod.subject}</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
             <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Lightbulb className="h-4 w-4 text-accent" />
                <span>AI Suggestion based on complementary skills.</span>
            </div>
            <div>
                <h4 className="text-sm font-semibold mb-2">Members</h4>
                <div className="flex items-center -space-x-2">
                  {pod.members.map(member => (
                    <Avatar key={member.id} className="border-2 border-card">
                      <AvatarImage src={member.avatarUrl} alt={member.name} />
                      <AvatarFallback>{getInitials(member.name)}</AvatarFallback>
                    </Avatar>
                  ))}
                </div>
            </div>
          </CardContent>
          <CardFooter className="flex gap-2">
            <Button variant="outline" className="w-full" onClick={() => handleDecision(pod.id, 'rejected')}>
              <X className="mr-2 h-4 w-4" /> Reject
            </Button>
            <Button className="w-full" onClick={() => handleDecision(pod.id, 'approved')}>
              <Check className="mr-2 h-4 w-4" /> Approve
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
